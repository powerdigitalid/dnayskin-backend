# DnaySkin - Backend

Backend for DnaySkin Project.

### TODO

- [x] Create proper `routes`
- [ ] Apply validateToken middleware to all routes.
