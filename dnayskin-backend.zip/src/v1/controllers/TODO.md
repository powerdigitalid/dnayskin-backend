# DnaySkin - Backend

Backend for DnaySkin Project.

## TODO

- [x] Place all controllers in `controllers` folder
- [x] Dashboard controller (counter for customer, product, treatment, current reservation)
- [ ] Enable JWT
- [x] Banner can be update, delete, and get by Id
