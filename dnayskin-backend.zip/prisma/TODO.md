# DnaySkin - Backend

Backend for DnaySkin Project.

### TODO

- [x] Add db schema
- [x] Add db seeder
